package finalProject;

import java.util.Arrays;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;

/**
 * Class that updates the values read from every sensor every 50ms and stores them in public variables. 
 * @author rabbani
 * @version 1.1
 */
public class SensorPoller extends Thread{

	// Instantiate Sensor Ports
	private static final Port portUs = LocalEV3.get().getPort("S3");
	private static final Port portUsSecond = LocalEV3.get().getPort("S1");
	private static final Port portColorBack = LocalEV3.get().getPort("S4");
	private static final Port portColorLauncher = LocalEV3.get().getPort("S2");
	
	// Sensor values that are constantly being updated
	static int valueUs, valueUsSecond;
	static float valueColorBack;
	static float valueColorLauncherRed;
	static float valueColorLauncherBlue;
	// US SENSOR
	SensorModes usSensor = new EV3UltrasonicSensor(portUs);
	SampleProvider usValue = usSensor.getMode("Distance");
	float[] usData = new float[usValue.sampleSize()];

	// SECOND US SENSOR (LEFT)
	SensorModes usSensorSecond = new EV3UltrasonicSensor(portUsSecond);
	SampleProvider usValueSecond = usSensorSecond.getMode("Distance");
	float[] usDataSecond = new float[usValueSecond.sampleSize()];
	
	
	// COLOR SENSOR BACK
	EV3ColorSensor colorSensorBack = new EV3ColorSensor(portColorBack);
	SampleProvider colorValueBack = colorSensorBack.getMode("Red");
	float[] colorDataBack = new float[colorValueBack.sampleSize()];


	// COLOR SENSOR LAUNCHER
	EV3ColorSensor colorSensorLauncher = new EV3ColorSensor(portColorLauncher);
	SampleProvider colorValueLauncher = colorSensorLauncher.getRGBMode();
	float[] colorDataLauncher = new float[colorValueLauncher.sampleSize()];
	
	
	public void run() {
		
		while (true) {
			
			usSensor.fetchSample(usData,0);							
			valueUs=(int)(usData[0]*100.0);			
			if (valueUs > 255)
				valueUs = 255;	
			
			usSensorSecond.fetchSample(usDataSecond, 0);
			valueUsSecond=(int)(usDataSecond[0]*100.0);
			if (valueUsSecond> 255)
				valueUsSecond = 255;	
			
			//colorSensorBack.fetchSample(colorDataBack, 0);
			//valueColorBack = (float)(colorDataBack[0]*100.0);
			
			colorSensorLauncher.fetchSample(colorDataLauncher, 0);
			colorSensorLauncher.fetchSample(colorDataLauncher, 2);
			valueColorLauncherRed = (float)(colorDataLauncher[0]*100.0);
			valueColorLauncherBlue = (float)(colorDataLauncher[2]*100.0);
			try { Thread.sleep(50); } catch(Exception e){}			
		}
	}
	
	// Getters for the sensor values
	public static int getValueUS(){
		return valueUs;
	}

	public static float getValusUSSecond() {
		return valueUsSecond;
	}
	public static float getValueColorBack() {
		return valueColorBack;
	}
	public static float getRedValueColorLauncher() {
		return valueColorLauncherRed;
	}
	public static float getBlueValueColorLauncher() {
		return valueColorLauncherBlue;
	}
}