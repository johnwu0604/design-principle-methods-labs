package finalProject;

import lejos.hardware.motor.EV3LargeRegulatedMotor;

public class Offense {
	private Odometer odo;
	private Navigation nav;
	EV3LargeRegulatedMotor pickUpMotor;
	EV3LargeRegulatedMotor launchMotor;
	private double blueBallValue = 0.1;				// VALUES NEED TESTING
	private double blueColorMargin = 0.05;
	private double redBallValue = 0.2;
	private double redColorMargin = 0.08;
	private int sweepAngle = 215;			// initial sweep of arm to bring ball up to sensor
	private int keepBallAngle = 40;			// if ball is desired color then push further up into trough 
	private int ballCount = 0;
	private int pickUpspeed = 45;
	public Offense(Navigation nav,Odometer odo){
		this.odo = odo;
		this.nav = nav;
		
		this.pickUpMotor = odo.getPickUpMotor();
		this.launchMotor = odo.getLaunchMotor();
	
	}
	
	public  void doOffense(){
		
		int corner= Main.getParameter(0);
		int forwadZoneWidth = Main.getParameter(4);
		
		
		//once it navigates to the ball rack, it picks up the ball one after the other
		
		for(int i = 0; i < 4; i++){
			pickUpBall();
			nav.goForward(5, false);
		}
		
		//then it navigates to the defense line
		nav.travelToTile(5, Main.getParameter(4));
		nav.travelToTile(5, 11-Main.getParameter(3));
		nav.turnTo(180);
		launch();
		
	
	}
	
	//sweeps ball, and holds up to the light sensor, if it is the right color
	// it will be pushed up farther into storage if not it will be released
	
	public void pickUpBall(){
		pickUpMotor.setSpeed(pickUpspeed);
		pickUpMotor.rotate(sweepAngle);
	
		int desiredBallType = Main.getParameter(9);
		if(desiredBallType==0){
			
			detectRedBall();
		}
		else if(desiredBallType==1){
			
			detectBlueBall();
		}
		else if(desiredBallType==2){
			ballCount++;
			pickUpMotor.rotate(keepBallAngle);
			pickUpMotor.rotate(-keepBallAngle-sweepAngle);
			
		}
		
		
	}

	// detects red ball based off of whether or not it is in a range
	// using rgb sensor so red ball will have high r value
	public boolean detectRedBall(){
		float redColorReading = SensorPoller.getRedValueColorLauncher();
		if(redColorReading <(redBallValue+redColorMargin) && redColorReading > (redBallValue -redColorMargin)){
			pickUpMotor.rotate(keepBallAngle);
			pickUpMotor.rotate(-keepBallAngle-sweepAngle);
			ballCount++;
			return true;
		}
		else{
			launchMotor.rotate(-sweepAngle);
			return false;
		}
	}
	// detects red ball based off of whether or not it is in a range
	// using rgb sensor so red ball will have high b value
	public boolean detectBlueBall(){
		float blueColorReading = SensorPoller.getBlueValueColorLauncher();
		if(blueColorReading <(blueBallValue+blueColorMargin) && blueColorReading > (blueBallValue -blueColorMargin)){
			pickUpMotor.rotate(keepBallAngle);
			pickUpMotor.rotate(-keepBallAngle-sweepAngle);
			ballCount++;
			return true;
		}
		else{
			launchMotor.rotate(-sweepAngle);
			return false;
		}
	}

	
	public void launch(){		//for now will just launch to middle of goal
		
		
		int acceleration = 2500;
		int launchSpeed = 2000;
		int launchAngle = 35;				// angle rotated when launching
		
		int rotateSpeed = 48;				// speed when picking up ball
		int pickUpAngle = 53;				// angle rotated to pick up
		
		int pickUpAcceleration = 100;
		
//		launchMotor.setSpeed(rotateSpeed);													// set values of speed and acceleration
		launchMotor.setAcceleration(pickUpAcceleration);
		launchMotor.setSpeed(rotateSpeed);													// set values of speed and acceleration
		launchMotor.rotate(pickUpAngle,false);
//		for(int i =0; i<ballCount; i++){
			launchMotor.setAcceleration(acceleration);
			launchMotor.setSpeed(launchSpeed);													
			launchMotor.rotate(launchAngle,false);
			launchMotor.setSpeed(rotateSpeed);													// set values of speed and acceleration
			launchMotor.setAcceleration(pickUpAcceleration);
			launchMotor.rotate(199-launchAngle - pickUpAngle,false); // corresponds to 360 degrees (the angle is different because we added gears) 
//		}

		
	}
	
	public void travelToBallRack(){
		double x = Main.getParameter(5);
		double y = Main.getParameter(6);
		nav.travelTo(x, y);
	}
}
