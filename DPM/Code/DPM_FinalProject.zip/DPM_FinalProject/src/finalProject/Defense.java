package finalProject;

/**
 * Defense class, that will go increase the width of the robot and start patrolling when called
 * @author holt
 * @version 0.1
 */
public class Defense {
	private Odometer odo;
	private Navigation nav;
	private final int TILE = 30;
	
	public Defense(Navigation nav,Odometer odo){
		this.odo = odo;
		this.nav = nav;
	}
	/**
	 * patrol method, used to guard to goal
	 */
	public void doDefense(int d1){
		//depending on the starting corner of the robot, it navigates to different corners and then to the defending zone. 
		if (Odometer.nearCorner == 1 || Odometer.nearCorner == 4 ){
			nav.travelTo(odo.X1[0], (odo.X4[1] - odo.X1[1]/2)); 
			nav.travelTo((odo.X4[0] - odo.X1[0]/2), (odo.X4[1] - odo.X1[1]/2));
			nav.travelTo((odo.X4[0] - odo.X1[0]/2), odo.X4[1] - d1*TILE);
			nav.turnTo(90);
			//one the robot gets to the defense line, it starts patroling (driving back and forth)
			patrol();
			}
		else {
			nav.travelTo(odo.X2[0], (odo.X3[1] - odo.X2[1]/2)); //change
			nav.travelTo((odo.X3[0] - odo.X2[0]/2), (odo.X3[1] - odo.X2[1]/2));
			nav.travelTo((odo.X3[0] - odo.X2[0]/2), odo.X3[1] - d1*TILE);
			nav.turnTo(90);
			patrol();
			
		}
	}
	
	public void patrol(){
		nav.goForward(-30,false);
			while(true){
		nav.goForward(60, false);
		nav.goForward(-60, false);
			}
	}
	
}
