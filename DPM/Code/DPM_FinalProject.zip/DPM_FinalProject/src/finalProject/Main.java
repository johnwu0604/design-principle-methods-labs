package finalProject;

import java.io.IOException;
import java.util.HashMap;

import lejos.hardware.Button;
import lejos.hardware.Sound;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.LCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;

/**
 * Main class, from where the user can decide to run tests, execute offense strategy or execute defense strategy
 * @author rabbani, holt
 * @version 1.3
 */
public class Main {
	public static int [] parameters=new int[10];
	//
	public final static int TILE = 30;

	public static void main(String[] args) throws InterruptedException {

		final SensorPoller sensorPoller = new SensorPoller();
		final Odometer odo = new Odometer();
		final DisplayLCD display = new DisplayLCD(odo);
		final Navigation nav = new Navigation(odo);
		final Localization loc = new Localization(odo, nav);
		final lightLocalization ll2 = new lightLocalization(odo, nav, sensorPoller.colorSensorBack);


		sensorPoller.start();
		odo.start();
		nav.start();

		LCD.drawString("< Offense	| 	Defend >	", 0, 0);
		LCD.drawString("		 DOWN-Wifi			", 0, 1);
		int buttonChoice = Button.waitForAnyPress();
		final Offense off = new Offense(nav,odo);
		final Defense def = new Defense(nav,odo);

		if(buttonChoice== Button.ID_LEFT){		// left for US sensor
			display.start();
			
			loc.doLocalization();
			ll2.doLocalization();
			odo.fixCorner(1);
			Sound.beepSequenceUp();
			nav.travelTo(4*TILE, 4*TILE);

			/*
			while(Button.waitForAnyPress() != Button.ID_ESCAPE) {
				off.testPickUp();
				Button.waitForAnyPress();
				off.launch();
			}
			 */


		} else if(buttonChoice== Button.ID_RIGHT){		// right for color sensor
			display.start();
			
			loc.doLocalization();
			ll2.doLocalization();
			odo.fixCorner(1);

			if (Odometer.nearCorner == 1 || Odometer.nearCorner ==4 ){
				nav.travelTo(Odometer.X1[0], (Odometer.X4[1] - Odometer.X1[1]/2)); //change
				nav.travelTo((Odometer.X4[0] - Odometer.X1[0]/2), (Odometer.X4[1] - Odometer.X1[1]/2));
				nav.travelTo((Odometer.X4[0] - Odometer.X1[0]/2), Odometer.X4[1] - 1*TILE);
				nav.turnTo(90);
				def.patrol();
				}
			else {
				nav.travelTo(Odometer.X2[0], (Odometer.X3[1] - Odometer.X2[1]/2)); //change
				nav.travelTo((Odometer.X3[0] - Odometer.X2[0]/2), (Odometer.X3[1] - Odometer.X2[1]/2));
				nav.travelTo((Odometer.X3[0] - Odometer.X2[0]/2), Odometer.X3[1] - 1*TILE);
				nav.turnTo(90);
				def.patrol();
				
			}


		}
		else 
		if(buttonChoice== Button.ID_DOWN){		// right for color sensor
			
			String serverIP = "192.168.1.157";
			int teamNumber = 3;
			
			WifiConnection wifi = null;
			while (true){
			try {
				wifi = new WifiConnection(serverIP, teamNumber);
			} catch (IOException e) {
				LCD.drawString("Connection failed", 0, 8);
			}
			
			//example use of StartData
			LCD.clear();
			if (wifi != null){
				HashMap<String,Integer> t = wifi.StartData;
				if (t == null) {
					LCD.drawString("Failed to read transmission", 0, 5);
				} else {
					LCD.drawString("Transmission read", 0, 5);
					LCD.drawString(t.toString(), 0, 6);
					
					/**
					 * Run Defense or Offense depending on Wifi class
					 */
					
					int defTeam = t.get("DTN");
					int offTeam = t.get("OTN");
					int ballLCC_x = t.get("ll-x");
					int ballLCC_y = t.get("ll-y");
					int goalWidth = t.get("w1");
					int defenseLine = t.get("d1");
					int offenseLine = t.get("d2");
					int ballColor = t.get("BC");
					int ballUR_x = t.get("ur-x");
					int ballUR_y = t.get("ur-y");
					
					
					parameters[2] = goalWidth;
					parameters[3] = defenseLine;
					parameters[4] = offenseLine;
					parameters[5] = ballLCC_x;
					parameters[6] = ballLCC_y;
					parameters[7] = ballUR_x;
					parameters[8] = ballUR_y;
					parameters[9] = ballColor;
					
					
					if (defTeam == 3){
						int startCorner = t.get("DSC");
						parameters[0] = startCorner;
						display.start();
						loc.doLocalization();
						ll2.doLocalization();
						odo.fixCorner(startCorner);
						if (Odometer.nearCorner == 1 || Odometer.nearCorner ==4 ){
							nav.travelTo(Odometer.X1[0], (Odometer.X4[1] - Odometer.X1[1]/2)); //change
							nav.travelTo((Odometer.X4[0] - Odometer.X1[0]/2), (Odometer.X4[1] - Odometer.X1[1]/2));
							nav.travelTo((Odometer.X4[0] - Odometer.X1[0]/2), Odometer.X4[1] - defenseLine*TILE);
							nav.turnTo(90);
							def.patrol();
							}
						else {
							nav.travelTo(Odometer.X2[0], (Odometer.X3[1] - Odometer.X2[1]/2)); //change
							nav.travelTo((Odometer.X3[0] - Odometer.X2[0]/2), (Odometer.X3[1] - Odometer.X2[1]/2));
							nav.travelTo((Odometer.X3[0] - Odometer.X2[0]/2), Odometer.X3[1] - defenseLine*TILE);
							nav.turnTo(90);
							def.patrol();
							
						}
					}
					
					else if (offTeam == 3) {
						int startCorner = t.get("OSC");
						parameters[0] = startCorner;
						display.start();
						loc.doLocalization();
						ll2.doLocalization();
						odo.fixCorner(startCorner);
						switch(startCorner){						
						case 1:  
							nav.travelToTile(1,1 );
							break;
						case 2:
							nav.travelToTile(9,1 );
							break;
						case 3:
							nav.travelToTile(9, offenseLine );
							break;
						case 4:
							nav.travelToTile(1,offenseLine );
							break;
						}
						nav.travelTo(parameters[5], parameters[6]); // ball rack 
						off.doOffense();
						
					}
					
				
				}
			} else {
				LCD.drawString("Connection failed", 0, 5);
			}
			
			Button.ESCAPE.waitForPress();

		}
		}
		while (Button.waitForAnyPress() != Button.ID_ESCAPE)
			;
		System.exit(0);
		
	}

	public static int getParameter(int index){
		return parameters[index];
	}
}
