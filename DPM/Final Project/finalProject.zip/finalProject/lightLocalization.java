package finalProject;

import lejos.hardware.Sound;
import lejos.hardware.Sounds;
import lejos.hardware.lcd.LCD;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.robotics.SampleProvider;

public class lightLocalization {
	private Odometer odo;
	private Navigation nav;
	
	//static Port lightPort  = LocalEV3.get().getPort("S2");
	//static EV3ColorSensor lightSensor = new EV3ColorSensor(lightPort);
	
	//private static final int ROTATE_SPEED = 150;
	//private ColorSensor cs;
	
	 // class parameters
	int dTx, dTy;
	double radius = 17.5;
	int angleX1, angleX2, angleY1, angleY2 = 0;
	double X , Y;

	private SampleProvider SP;
	private EV3ColorSensor colorSensor;
	

	//private double WHEEL_RADIUS;
	//private double WHEEL_WIDTH;
	//private int SPEED_ROTATE;
	
	
	//constructor
	public lightLocalization(Odometer odo, Navigation nav, EV3ColorSensor colorSensor) {
		this.odo = odo;
		this.nav = nav;
		this.colorSensor = colorSensor;
		this.SP = this.colorSensor.getRedMode();
		
		//this.WHEEL_RADIUS = odo.get_WHEEL_RADIUS();
		//this.WHEEL_WIDTH = odo.get_WHEEL_RADIUS();
		//this.SPEED_ROTATE = nav.getSPEED_ROTATE();
		
		
		
		LCD.clear();
		// turn on the light
	}
	
	
	// main function
	public void doLocalization(){
		angleX1 = 0; 
		angleX2 = 0; 
		angleY1 = 0; 
		angleY2 = 0;
		
		while(true){
			
			float[] sample = new float[SP.sampleSize()];
			SP.fetchSample(sample, 0);
			float sample_int = (float) sample[0] * 100;
	
			
			
			//starts rotating clockwise
			nav.rotate(true);
			
			//get the 4 lines
			
			if( sample_int < 40){
				if( ((90 * (Math.PI/180)) + 0.7853) > odo.getTheta() && odo.getTheta() > (0*(Math.PI/180) + 0.7853)){
					angleX1 = (int)(odo.getTheta() * 180 / Math.PI);
					Sound.beep();
					
				}
				if( 180*(Math.PI/180) + 0.7853 > odo.getTheta() && odo.getTheta() > 90*(Math.PI/180) + 0.7853 ){
					angleY1 = (int)(odo.getTheta() * 180 / Math.PI);
					Sound.beep();
					
				}
				if( 270*(Math.PI/180) + 0.7853 > odo.getTheta() && odo.getTheta() > 180*(Math.PI/180) + 0.7853 ){
					angleX2 = (int)(odo.getTheta() * 180 / Math.PI);
					Sound.beep();
					
				}
				if( 45*(Math.PI/180)  > odo.getTheta() || odo.getTheta() > 270*(Math.PI/180) + 0.7853 ){
					angleY2 = (int)(odo.getTheta() * 180 / Math.PI);
					Sound.beep();
					
				}
		
			}
			if(angleX1 != 0 && angleX2 != 0 && angleY1 != 0 && angleY2 != 0){
				
				nav.stopMotors();
				break;
			}
			
			
		}
		
		// print to screen
		dTx = (int) ((angleX2 - angleX1));
		dTy = (int)((angleY2 - angleY1));
		//System.out.println("        ");
		//System.out.println("        ");
		//System.out.println("        ");
		//System.out.println("        " + dTx +" "+ dTy);
		//System.out.println(angleX1 +" "+ angleX2 +" "+ angleY1 +" "+angleY2);
		calX(dTy);
		calY(dTx);
	
	
		
		nav.travelTo(0, 0);
		nav.turnTo(0);
		fixAngle(Math.toRadians(15),1);
		
		
	}
	private void calX(double dTy){
		this.dTy = (int) dTy;
		X =  -1 * radius * ( Math.cos( (dTy/2) *Math.PI/180  ));
		odo.setX(X);
	}
	private void calY(double dTx){
		this.dTx = (int) dTx;
		Y =  -1 * radius * ( Math.cos( (dTx/2) *Math.PI/180  ));
		odo.setY(Y);
	}
	
	public void fixAngle(double sweepAngle, int attempts){
		Sound.beepSequence();
		boolean foundLine = false;
		nav.rotate(false);
		float[] sample = new float[SP.sampleSize()];
		float sample_int;
		while(odo.getTheta() < sweepAngle){
			
			SP.fetchSample(sample, 0);
			sample_int = (float) sample[0] * 100;
			if(sample_int < 35){
				nav.stopMotors();
				Sound.buzz();
				odo.setTheta(0);
				foundLine = true;
				break;
			}
		}
		
		
		if(!foundLine){
			nav.turnTo(0);		
			odo.setTheta(359.99);
			nav.rotate(true);
			while(odo.getTheta()> 360-sweepAngle){
			
				SP.fetchSample(sample, 0);
				sample_int = (float) sample[0] * 100;
				if(sample_int<40){
					nav.stopMotors();
					Sound.buzz();
					odo.setTheta(0);
					foundLine = true;
					break;
				}
					
			}
		}
		
		if(!foundLine && attempts < 3)
		{
			fixAngle(sweepAngle+10,attempts +1);
		}
		
		Sound.buzz();
	}
	

}