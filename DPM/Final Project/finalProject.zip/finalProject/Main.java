package finalProject;

import lejos.hardware.Button;
import lejos.hardware.Sound;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.LCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.SensorModes;
import lejos.robotics.SampleProvider;
/**
 * Main class, from where the user can decide to run tests, execute offense strategy or execute defense strategy
 * @author rabbani, holt
 * @version 1.3
 */
public class Main {
	public static int [] parameters={2,6,5,7,6,0,0,0,0,0};
	public final static int TILE = 30;

	public static void main(String[] args) throws InterruptedException {

		final SensorPoller sensorPoller = new SensorPoller();
		final Odometer odo = new Odometer();
		final DisplayLCD display = new DisplayLCD(odo);
		final Navigation nav = new Navigation(odo);
		final Localization loc = new Localization(odo, nav);
		final lightLocalization ll2 = new lightLocalization(odo, nav, sensorPoller.colorSensorBack);
		
		
		sensorPoller.start();
		odo.start();
		nav.start();
		
		LCD.drawString("< Left	| 	Right >	", 0, 0);
		int buttonChoice = Button.waitForAnyPress();
		display.start();
		final Offense off = new Offense(nav,odo);
		
		if(buttonChoice== Button.ID_LEFT){		// left for US sensor
			
			while(Button.waitForAnyPress() != Button.ID_ESCAPE) {
				off.testPickUp();
				Button.waitForAnyPress();
				off.launch();
			}
				
			
		
		} else if(buttonChoice== Button.ID_RIGHT){		// right for color sensor

			while(true){
				loc.doLocalization();
				ll2.doLocalization();
				Button.waitForAnyPress();
			}
			
			
//			nav.travelTo(parameters[1]*TILE-15, parameters[2]*TILE);
//			nav.leftMotor.waitComplete();
//			nav.rightMotor.waitComplete();
//			nav.turnTo(180-60);
//			off.testPickUp();
//			nav.turnTo(45);
//			off.launch();
			
			
		}
		
		while (Button.waitForAnyPress() != Button.ID_ESCAPE)
			;
		System.exit(0);
	}

	public static int getParameter(int index){
		return parameters[index];
	}
}
