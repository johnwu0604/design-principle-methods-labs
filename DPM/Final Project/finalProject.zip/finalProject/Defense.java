package finalProject;

/**
 * Defense class, that will go increase the width of the robot and start patrolling when called
 * @author holt
 * @version 0.1
 */
public class Defense {
	private Odometer odo;
	private Navigation nav;
	
	public Defense(Navigation nav,Odometer odo){
		this.odo = odo;
		this.nav = nav;
	}
	/**
	 * patrol method, used to guard to goal
	 */
	public void doDefense(){
		
	}
	
	public void patrol(){
		
		// must develop random way to patrol goal
		
	}
	/**
	 * increaseWidth method, that will use the catapult and the loader to increase the width of the robot
	 */
	public void increaseWidth(){
		
		//set orientation of arm etc
		
	}
	
	
	
}
